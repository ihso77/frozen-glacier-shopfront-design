const Eris = require('eris')
const fs = require('fs')

const Prefix = ''/// بيرفكس
const MainToken = ""

const owners = []

// Load tokens from list and file
let TokensList = [];

try {
    if (fs.existsSync('./tokens.json')) {
        const fileTokens = JSON.parse(fs.readFileSync('./tokens.json', 'utf-8'));
        if (Array.isArray(fileTokens)) {
            TokensList = [...new Set([...TokensList, ...fileTokens])];
        }
    }
} catch (e) {
    console.error("Error loading tokens.json:", e.message);
}

const skipRole1 = ''// رتبة 1 الي ما توصلها برود
const skipRole2 = ''// رتبة 2 الي ما توصلها برود

let Bots = []
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Helper: Split long messages
function splitMessage(text, maxLength = 2000) {
    if (text.length <= maxLength) return [text];
    const messages = [];
    let current = "";
    for (const line of text.split("\n")) {
        if (current.length + line.length + 1 > maxLength) {
            messages.push(current);
            current = line;
        } else {
            current += (current ? "\n" : "") + line;
        }
    }
    if (current) messages.push(current);
    return messages;
}

const client = new Eris(MainToken, { 
    restMode: true, 
    intents: ['guilds', 'directMessages', 'guildMembers', 'guildMessages', 'guildPresences'], 
    getAllUsers: true 
});

client.on('ready', () => console.log(`\x1b[34m[MAIN BOT] ${client.user.username} (${client.user.id})\x1b[0m`));

(async () => {
    console.log(`\x1b[33m[SYSTEM] Starting ${TokensList.length} sub-bots...\x1b[0m`);
    for (let token of TokensList) {
        if (!token) continue;
        let bot = new Eris(token, {
            restMode: true,
            intents: ['guilds', 'directMessages', 'guildMembers', 'guildMessages']
        });
        bot.on('ready', () => {
            console.log(`\x1b[32m[${Bots.length + 1}] ${bot.user.username} (${bot.user.id}) Connected.\x1b[0m`)
        });
        bot.on('error', (err) => console.error(`[BOT ERROR] ${token.slice(0, 10)}... : ${err.message}`));
        
        try {
            await bot.connect();
            Bots.push(bot);
        } catch (e) {
            console.error(`[FAILED] Could not connect bot with token starting with ${token.slice(0, 10)}`);
        }
    }
    client.connect();
})()

client.on('messageCreate', async message => {
    if (!message?.channel?.guild) return;
    if (message.author.bot) return;
    if (!owners.includes(message.author.id)) return;

    if (message.content === '-bc' || message.content.startsWith(Prefix + 'bc')) {
        let missingBots = Bots.filter(bot => !bot.guilds.get(message.channel.guild.id));
        if (missingBots.length > 0) {
            let msgContent = missingBots.map(c => `**\`-\` <@${c.user.id}> is not on this server :**\nhttps://discord.com/api/oauth2/authorize?client_id=${c.user.id}&permissions=0&integration_type=0&scope=bot`).join('\n');
            const chunks = splitMessage(msgContent);
            for (const chunk of chunks) {
                await client.createMessage(message.channel.id, chunk);
            }
            return;
        }

        // Target Selection with Buttons
        const selectionMsg = await client.createMessage(message.channel.id, {
            embed: {
                title: 'اختار الفئة المستهدفة للبرودكاست',
                color: 0x5865F2,
                timestamp: new Date()
            },
            components: [{
                type: 1,
                components: [
                    { type: 2, style: 1, label: 'أونلاين', custom_id: 'bc_online' },
                    { type: 2, style: 1, label: 'أوفلاين', custom_id: 'bc_offline' },
                    { type: 2, style: 1, label: 'الكل', custom_id: 'bc_all' }
                ]
            }]
        });

        const buttonListener = async (interaction) => {
            if (interaction instanceof Eris.ComponentInteraction && interaction.message.id === selectionMsg.id && interaction.member.id === message.author.id) {
                client.off('interactionCreate', buttonListener);
                clearTimeout(selectionTimeout);
                
                await interaction.acknowledge();
                await selectionMsg.delete().catch(() => {});
                
                let targetType = interaction.data.custom_id.split('_')[1];
                let members = await message.channel.guild.fetchMembers();
                
                if (targetType === 'online') {
                    members = members.filter(m => !m.bot && m.status && m.status !== 'offline');
                } else if (targetType === 'offline') {
                    members = members.filter(m => !m.bot && (!m.status || m.status === 'offline'));
                } else {
                    members = members.filter(m => !m.bot);
                }

                if (skipRole1) members = members.filter(m => !m.roles.includes(skipRole1));
                if (skipRole2) members = members.filter(m => !m.roles.includes(skipRole2));

                if (members.length === 0) {
                    return client.createMessage(message.channel.id, '**❌ لا يوجد أعضاء في هذه الفئة!**');
                }

                const promptMsg = await client.createMessage(message.channel.id, '**قم بكتابة الرسالة الآن...**');
                
                const messageListener = async (m) => {
                    if (m.author.id === message.author.id && m.channel.id === message.channel.id) {
                        client.off('messageCreate', messageListener);
                        clearTimeout(msgTimeout);
                        
                        let broadcastContent = m.content;
                        await promptMsg.delete().catch(() => {});
                        await m.delete().catch(() => {});

                        startBroadCast(members, broadcastContent, message.channel);
                    }
                };
                client.on('messageCreate', messageListener);
                const msgTimeout = setTimeout(() => client.off('messageCreate', messageListener), 60000);
            }
        };

        client.on('interactionCreate', buttonListener);
        const selectionTimeout = setTimeout(() => {
            client.off('interactionCreate', buttonListener);
            selectionMsg.delete().catch(() => {});
        }, 60000);
    }
});

async function startBroadCast(members, content, channel) {
    const total = members.length;
    let sent = 0;
    let failed = 0;

    const getProgressBar = (current, total) => {
        const size = 15;
        const progress = Math.min(size, Math.round((current / total) * size));
        const emptyProgress = size - progress;
        return `\`${'■'.repeat(progress)}${'□'.repeat(emptyProgress)}\` **${((current / total) * 100).toFixed(2)}%**`;
    };

    const embedData = () => ({
        embed: {
            title: 'معلومات الإرسال',
            description: 'هنا تجد جميع المعلومات المتعلقة بعملية الإرسال.',
            thumbnail: { url: 'https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExZ3F0eWVpdzNybjc1bXQ2ZWtkYWU0b2RpbzFkeHBvNGoxMHdlNzk0dSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWRmY3Q9Zw/17mNCcKU1mJlrbXodo/giphy.gif' },
            color: 0x2b2d31,
            fields: [
                { name: '┃ الأعضاء', value: `\`${total}\``, inline: true },
                { name: '┃ الوقت المتوقع', value: `\`${Math.ceil((total - (sent + failed)) * 1.5 / Math.max(1, Bots.length))} ثانية\``, inline: true },
                { name: '\u200b', value: '\u200b', inline: true },
                { name: '┃ تم الإرسال', value: `\`${sent}\``, inline: true },
                { name: '┃ متبقي', value: `\`${Math.max(0, total - (sent + failed))}\``, inline: true },
                { name: '┃ فشل', value: `\`${failed}\``, inline: true },
                { name: 'التقدم', value: getProgressBar(sent + failed, total) },
                { name: 'محتوى الرسالة', value: content.length > 500 ? content.slice(0, 500) + '...' : content }
            ],
            footer: { text: 'Nova Store' },
            timestamp: new Date()
        }
    });

    let statusMsg = await client.createMessage(channel.id, embedData());

    const updateInterval = setInterval(async () => {
        await statusMsg.edit(embedData()).catch(() => {});
        if (sent + failed >= total) {
            clearInterval(updateInterval);
            await statusMsg.edit({
                embed: {
                    ...embedData().embed,
                    title: '✅ تم انتهاء الإرسال بنجاح',
                    color: 0x00ff00
                }
            }).catch(() => {});
        }
    }, 4000);

    const chunkSize = Math.ceil(members.length / Math.max(1, Bots.length));
    const membersChunks = [];
    for (let i = 0; i < members.length; i += chunkSize) {
        membersChunks.push(members.slice(i, i + chunkSize));
    }

    await Promise.all(membersChunks.map(async (chunk, botIndex) => {
        const bot = Bots[botIndex] || Bots[0];
        if (!bot) return;
        for (const member of chunk) {
            try {
                const dmChannel = await bot.getDMChannel(member.id);
                await dmChannel.createMessage(`${content}\n<@${member.id}>`);
                sent++;
            } catch (e) {
                failed++;
            }
            await sleep(1500); 
        }
    }));
}

/*Handle Errors*/
process.on('uncaughtException', e => console.log(`[Uncaught Exception] ${e.stack || e}`));
process.on('unhandledRejection', (reason, promise) => console.log(`[Unhandled Rejection] ${reason}`));